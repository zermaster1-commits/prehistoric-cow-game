import { baseStats, MUTATIONS, pickChoices, type MutationDef, type Stats } from './mutations';

export type GameState = 'menu' | 'playing' | 'paused' | 'evolve' | 'dead';

export type Hud = {
  state: GameState;
  hp: number;
  maxHp: number;
  hunger: number;
  maxHunger: number;
  dna: number;
  dnaNeed: number;
  level: number;
  score: number;
  time: number;
  era: number;
  eraName: string;
  biome: string;
  kills: number;
  abilities: { key: string; name: string; icon: string; ready: number; charges: number; maxCharges: number }[];
  choices: { def: MutationDef; tier: number }[];
  traits: { name: string; icon: string; tier: number; color: string }[];
  combo: number;
};

export type Input = {
  up: boolean; down: boolean; left: boolean; right: boolean;
  ax: number; ay: number; // analog
  attack: boolean; dash: boolean; skill1: boolean; skill2: boolean;
};

const TAU = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const rnd = (a = 1, b = 0) => b + Math.random() * (a - b);

function hash2(x: number, y: number) {
  let h = x * 374761393 + y * 668265263;
  h = (h ^ (h >> 13)) * 1274126177;
  return ((h ^ (h >> 16)) >>> 0) / 4294967296;
}
function noise(x: number, y: number) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  return lerp(
    lerp(hash2(xi, yi), hash2(xi + 1, yi), u),
    lerp(hash2(xi, yi + 1), hash2(xi + 1, yi + 1), u),
    v,
  );
}

export const BIOMES = [
  { name: 'Verdant Plains', ground: '#2f7a46', ground2: '#276539', detail: '#3f9a57', sky: '#9fe3b0' },
  { name: 'Fern Forest', ground: '#1f5c3d', ground2: '#174a32', detail: '#2f8552', sky: '#7fd0a0' },
  { name: 'Tar Swamp', ground: '#3b4a33', ground2: '#2d3a28', detail: '#55683f', sky: '#9fae7a' },
  { name: 'Frost Steppe', ground: '#6f8ca6', ground2: '#5d7a94', detail: '#9fc0d6', sky: '#cfe6f5' },
  { name: 'Ash Volcanics', ground: '#4a3334', ground2: '#3a2728', detail: '#7a3d2e', sky: '#e0a17a' },
];

const ERAS = ['Dawn Age', 'Fern Age', 'Raptor Age', 'Thunder Age', 'Ash Age', 'Ice Age', 'Cataclysm'];

type Particle = { x: number; y: number; vx: number; vy: number; life: number; max: number; r: number; c: string; g?: number; shape?: number };
type Floater = { x: number; y: number; vy: number; life: number; text: string; c: string; s: number };

type Enemy = {
  x: number; y: number; vx: number; vy: number; hp: number; maxHp: number; r: number;
  type: string; dmg: number; speed: number; hit: number; atkCd: number; poison: number; poisonT: number;
  stun: number; dna: number; color: string; phase: number; dead?: boolean; elite?: boolean;
};
type Food = { x: number; y: number; amount: number; max: number; r: number; kind: number; phase: number; dna: number };
type Orb = { x: number; y: number; vx: number; vy: number; v: number; kind: 'dna' | 'meat'; life: number };
type Shot = { x: number; y: number; vx: number; vy: number; life: number; dmg: number; friendly: boolean; r: number; kind: string };

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  w = 800; h = 600; dpr = 1;
  state: GameState = 'menu';
  onHud: (h: Hud) => void = () => {};

  input: Input = { up: false, down: false, left: false, right: false, ax: 0, ay: 0, attack: false, dash: false, skill1: false, skill2: false };

  // player
  px = 0; py = 0; pvx = 0; pvy = 0; face = 0; legPhase = 0;
  hp = 100; hunger = 100; stats: Stats = baseStats();
  owned: Record<string, number> = {};
  visuals: Record<string, number> = {};
  abilities: string[] = ['dash'];
  cd: Record<string, number> = {};
  dashCharge = 1; dashTimer = 0; iframes = 0; hitFlash = 0; poisonAura = 0;
  attackTimer = 0; attackCd = 0; grazing = 0;

  dna = 0; totalDna = 0; level = 1; kills = 0; time = 0; combo = 0; comboT = 0;
  choices: { def: MutationDef; tier: number }[] = [];

  enemies: Enemy[] = []; foods: Food[] = []; orbs: Orb[] = []; shots: Shot[] = [];
  parts: Particle[] = []; floats: Floater[] = [];
  orbitAngle = 0;

  camx = 0; camy = 0; shake = 0; shakeA = 0; hitstop = 0; flashW = 0;
  spawnT = 0; foodT = 0; eliteT = 25;
  raf = 0; last = 0; acc = 0; hudTick = 0; lastHint = -1;
  running = false;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.resize();
  }

  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.dpr = dpr; this.w = w; this.h = h;
    this.canvas.width = Math.floor(w * dpr);
    this.canvas.height = Math.floor(h * dpr);
  }

  start() {
    this.px = 0; this.py = 0; this.pvx = 0; this.pvy = 0; this.face = -Math.PI / 2;
    this.stats = baseStats();
    this.owned = {}; this.visuals = {}; this.abilities = ['dash']; this.cd = {};
    this.hp = this.stats.maxHp; this.hunger = this.stats.maxHunger;
    this.dna = 0; this.totalDna = 0; this.level = 1; this.kills = 0; this.time = 0;
    this.combo = 0; this.comboT = 0;
    this.enemies = []; this.foods = []; this.orbs = []; this.shots = []; this.parts = []; this.floats = [];
    this.dashCharge = this.stats.dashCharges; this.iframes = 0; this.hitFlash = 0;
    this.spawnT = 2.2; this.eliteT = 30; this.shake = 0; this.hitstop = 0;
    this.camx = 0; this.camy = 0;
    for (let i = 0; i < 70; i++) this.spawnFood(true);
    for (let i = 0; i < 3; i++) this.spawnEnemy();
    this.state = 'playing';
    this.pushHud();
  }

  get score() {
    return Math.floor(this.totalDna * 2 + this.kills * 30 + this.time * 4 + (this.level - 1) * 80);
  }

  biomeIdx(x: number, y: number) {
    const n = noise(x / 1500 + 100, y / 1500 + 100) * 0.65 + noise(x / 620, y / 620) * 0.35;
    return clamp(Math.floor(n * 5.2), 0, 4);
  }

  // ---------- spawning ----------
  spawnFood(initial = false) {
    const a = rnd(TAU), d = initial ? rnd(1300, 120) : rnd(1400, 800);
    const x = this.px + Math.cos(a) * d, y = this.py + Math.sin(a) * d;
    const b = this.biomeIdx(x, y);
    const kind = b === 3 ? 2 : b === 4 ? 3 : b === 2 ? 1 : hash2(Math.floor(x), Math.floor(y)) > 0.8 ? 1 : 0;
    this.foods.push({ x, y, amount: 100, max: 100, r: 16 + rnd(10), kind, phase: rnd(TAU), dna: kind === 3 ? 14 : kind === 1 ? 10 : 7 });
  }

  spawnEnemy(elite = false) {
    const a = rnd(TAU), d = rnd(1000, 680);
    const x = this.px + Math.cos(a) * d, y = this.py + Math.sin(a) * d;
    const b = this.biomeIdx(x, y);
    const era = this.era;
    const pool = [
      ['raptor', 'dodo', 'raptor'],
      ['raptor', 'raptor', 'sabre'],
      ['bug', 'spitter', 'raptor'],
      ['sabre', 'yeti', 'bug'],
      ['magma', 'spitter', 'sabre'],
    ][b];
    const type = pool[Math.floor(rnd(pool.length))];
    const sc = 1 + era * 0.4 + this.time / 110;
    const base: Record<string, Partial<Enemy> & { r: number; color: string }> = {
      dodo: { r: 16, color: '#e8b84b', hp: 22, dmg: 5, speed: 80 },
      raptor: { r: 17, color: '#d2694a', hp: 32, dmg: 9, speed: 162 },
      sabre: { r: 22, color: '#b98b4e', hp: 62, dmg: 16, speed: 138 },
      bug: { r: 14, color: '#8bd14a', hp: 20, dmg: 7, speed: 190, poison: 4 },
      spitter: { r: 19, color: '#7c5ccc', hp: 40, dmg: 10, speed: 92 },
      yeti: { r: 27, color: '#cfe6f5', hp: 105, dmg: 20, speed: 104 },
      magma: { r: 24, color: '#ef6c3a', hp: 85, dmg: 22, speed: 120 },
    };
    const t = base[type];
    const hp = (t.hp as number) * sc * (elite ? 4 : 1);
    this.enemies.push({
      x, y, vx: 0, vy: 0, hp, maxHp: hp, r: t.r * (elite ? 1.7 : 1), type,
      dmg: (t.dmg as number) * (0.7 + sc * 0.35) * (elite ? 1.5 : 1),
      speed: (t.speed as number) * (1 + era * 0.02) * (elite ? 0.88 : 1),
      hit: 0, atkCd: 0, poison: (t.poison as number) || 0, poisonT: 0, stun: 0,
      dna: (8 + (t.hp as number) * 0.28) * (elite ? 7 : 1), color: t.color, phase: rnd(TAU), elite,
    });
  }

  get era() { return Math.min(6, Math.floor(this.time / 55) + 1); }

  // ---------- effects ----------
  burst(x: number, y: number, n: number, c: string, spd = 180, life = 0.5, r = 3) {
    for (let i = 0; i < n; i++) {
      if (this.parts.length > 520) break;
      const a = rnd(TAU), s = rnd(spd, spd * 0.25);
      this.parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life, max: life, r: rnd(r * 1.6, r * 0.5), c, g: 0.4 });
    }
  }
  float(x: number, y: number, text: string, c = '#fff', s = 1) {
    if (this.floats.length > 40) this.floats.shift();
    this.floats.push({ x, y, vy: -46, life: 0.9, text, c, s });
  }
  doShake(amt: number) { this.shake = Math.min(28, this.shake + amt); }

  // ---------- combat ----------
  damageEnemy(e: Enemy, dmg: number, kx: number, ky: number, crit = false) {
    e.hp -= dmg; e.hit = 0.16;
    e.vx += kx; e.vy += ky;
    if (this.stats.poison > 0) { e.poison = this.stats.poison; e.poisonT = 3; }
    if (this.stats.lifesteal > 0) this.heal(dmg * this.stats.lifesteal);
    this.burst(e.x, e.y, crit ? 14 : 7, crit ? '#ffe066' : '#ff9a62', 220, 0.42, 3.4);
    this.float(e.x, e.y - e.r, (crit ? '✦' : '') + Math.round(dmg), crit ? '#ffe066' : '#ffd9c0', crit ? 1.3 : 1);
    if (e.hp <= 0 && !e.dead) this.killEnemy(e);
  }

  killEnemy(e: Enemy) {
    e.dead = true;
    this.kills++;
    this.combo++; this.comboT = 3.4;
    this.doShake(e.elite ? 16 : 6);
    this.hitstop = Math.max(this.hitstop, e.elite ? 0.12 : 0.05);
    this.burst(e.x, e.y, e.elite ? 40 : 18, e.color, 300, 0.7, 4.5);
    this.burst(e.x, e.y, 10, '#ffffff', 420, 0.3, 2.5);
    const n = Math.ceil(e.dna / 7);
    for (let i = 0; i < n; i++) {
      const a = rnd(TAU), s = rnd(190, 60);
      this.orbs.push({ x: e.x, y: e.y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, v: e.dna / n, kind: 'dna', life: 18 });
    }
    if (Math.random() < 0.35 || e.elite) this.orbs.push({ x: e.x, y: e.y, vx: rnd(60, -60), vy: rnd(60, -60), v: e.elite ? 40 : 16, kind: 'meat', life: 18 });
    this.float(e.x, e.y - 20, e.elite ? 'ALPHA SLAIN!' : 'EVOLVE +' + Math.round(e.dna), '#7dffb2', e.elite ? 1.6 : 1.1);
  }

  heal(v: number) {
    this.hp = Math.min(this.stats.maxHp, this.hp + v);
  }

  hurt(dmg: number, fromX: number, fromY: number) {
    if (this.iframes > 0) return;
    const d = Math.max(1, dmg - this.stats.armor * 0.8) * 1;
    this.hp -= d;
    this.iframes = 0.55; this.hitFlash = 0.35;
    this.combo = 0;
    const a = Math.atan2(this.py - fromY, this.px - fromX);
    this.pvx += Math.cos(a) * 240; this.pvy += Math.sin(a) * 240;
    this.doShake(9 + d * 0.3);
    this.hitstop = Math.max(this.hitstop, 0.055);
    this.flashW = 0.35;
    this.burst(this.px, this.py, 12, '#ff5a5a', 240, 0.5, 3.6);
    this.float(this.px, this.py - 30, '-' + Math.round(d), '#ff6b6b', 1.2);
    if (this.hp <= 0) this.die();
  }

  die() {
    this.hp = 0;
    this.state = 'dead';
    this.doShake(24);
    this.burst(this.px, this.py, 60, '#ffd9c0', 380, 1.1, 5);
    this.pushHud();
  }

  attack() {
    if (this.attackCd > 0) return;
    this.attackCd = 0.46 / this.stats.atkSpeed;
    this.attackTimer = 0.2;
    const sp = Math.hypot(this.pvx, this.pvy);
    this.pvx += Math.cos(this.face) * 300; this.pvy += Math.sin(this.face) * 300;
    const reach = 54 * this.stats.size + this.stats.horn * 14;
    const hx = this.px + Math.cos(this.face) * reach * 0.6;
    const hy = this.py + Math.sin(this.face) * reach * 0.6;
    let hitAny = false;
    for (const e of this.enemies) {
      const dx = e.x - hx, dy = e.y - hy;
      if (dx * dx + dy * dy < (reach + e.r) * (reach + e.r)) {
        const crit = Math.random() < this.stats.crit;
        const bonus = 1 + Math.min(sp / 420, 1) * 0.5;
        const dmg = this.stats.damage * bonus * (crit ? 2.3 : 1);
        const a = Math.atan2(dy, dx);
        this.damageEnemy(e, dmg, Math.cos(a) * 330 * this.stats.knockback, Math.sin(a) * 330 * this.stats.knockback, crit);
        e.stun = 0.18;
        hitAny = true;
      }
    }
    if (hitAny) { this.doShake(7); this.hitstop = Math.max(this.hitstop, 0.045); }
    this.burst(hx, hy, 6, '#fff3c4', 150, 0.26, 2.6);
  }

  useDash() {
    if (this.dashCharge < 1 || this.dashTimer > 0) return;
    this.dashCharge -= 1;
    this.dashTimer = 0.2; this.iframes = Math.max(this.iframes, 0.3);
    const a = (this.input.ax || this.input.ay) ? Math.atan2(this.input.ay, this.input.ax) : this.face;
    this.face = a;
    this.pvx = Math.cos(a) * 900; this.pvy = Math.sin(a) * 900;
    this.doShake(5);
    this.burst(this.px, this.py, 16, '#9fe8ff', 260, 0.45, 3.4);
  }

  useSkill(slot: number) {
    const list = this.abilities.filter((a) => a !== 'dash');
    const key = list[slot];
    if (!key) return;
    if ((this.cd[key] || 0) > 0) return;
    if (key === 'mortar') {
      this.cd[key] = 1.5;
      const t = this.owned['mortar'] || 1;
      const tgt = this.nearestEnemy(700);
      const a = tgt ? Math.atan2(tgt.y - this.py, tgt.x - this.px) : this.face;
      for (let i = 0; i < Math.min(3, t); i++) {
        const sp = 520, off = (i - (Math.min(3, t) - 1) / 2) * 0.22;
        this.shots.push({ x: this.px, y: this.py, vx: Math.cos(a + off) * sp, vy: Math.sin(a + off) * sp, life: 1.1, dmg: this.stats.damage * (1.1 + t * 0.25), friendly: true, r: 9, kind: 'milk' });
      }
      this.doShake(3);
    } else if (key === 'stomp') {
      this.cd[key] = 3.2;
      const t = this.owned['stomp'] || 1;
      const R = 150 + t * 34;
      for (const e of this.enemies) {
        const dx = e.x - this.px, dy = e.y - this.py;
        const d = Math.hypot(dx, dy);
        if (d < R + e.r) {
          const a = Math.atan2(dy, dx);
          this.damageEnemy(e, this.stats.damage * (1.2 + t * 0.3), Math.cos(a) * 600, Math.sin(a) * 600);
          e.stun = 0.6;
        }
      }
      for (let i = 0; i < 34; i++) {
        const a = (i / 34) * TAU;
        this.parts.push({ x: this.px, y: this.py, vx: Math.cos(a) * R * 2.4, vy: Math.sin(a) * R * 2.4, life: 0.42, max: 0.42, r: 6, c: '#ffc46b', g: 0 });
      }
      this.doShake(16); this.hitstop = Math.max(this.hitstop, 0.07); this.flashW = 0.2;
    }
  }

  nearestEnemy(range: number): Enemy | null {
    let best: Enemy | null = null, bd = range * range;
    for (const e of this.enemies) {
      const d = (e.x - this.px) ** 2 + (e.y - this.py) ** 2;
      if (d < bd) { bd = d; best = e; }
    }
    return best;
  }

  // ---------- evolution ----------
  get dnaNeed() { return Math.floor(32 + this.level * 18 + Math.pow(this.level, 1.6) * 7); }

  levelUp() {
    this.dna -= this.dnaNeed;
    this.level++;
    this.choices = pickChoices(this.level, this.owned, Math.random);
    this.state = 'evolve';
    this.burst(this.px, this.py, 50, '#7dffb2', 330, 1, 4.5);
    this.doShake(10);
    this.float(this.px, this.py - 50, 'EVOLUTION!', '#7dffb2', 1.8);
    this.pushHud();
  }

  choose(i: number) {
    const c = this.choices[i];
    if (!c) return;
    this.owned[c.def.key] = (this.owned[c.def.key] || 0) + 1;
    c.def.apply(this.stats, c.tier);
    if (c.def.grants && !this.abilities.includes(c.def.grants)) this.abilities.push(c.def.grants);
    if (c.def.visual) this.visuals[c.def.visual] = (this.visuals[c.def.visual] || 0) + 1;
    this.hp = Math.min(this.stats.maxHp, this.hp + 22);
    this.hunger = Math.min(this.stats.maxHunger, this.hunger + 18);
    this.dashCharge = this.stats.dashCharges;
    this.choices = [];
    this.state = this.dna >= this.dnaNeed ? 'playing' : 'playing';
    this.burst(this.px, this.py, 30, c.def.color, 300, 0.8, 4);
    if (this.dna >= this.dnaNeed) this.levelUp();
    this.pushHud();
  }

  // ---------- loop ----------
  loop = (t: number) => {
    this.raf = requestAnimationFrame(this.loop);
    if (!this.last) this.last = t;
    let dt = (t - this.last) / 1000;
    this.last = t;
    if (dt > 0.1) dt = 0.1;
    if (this.state === 'playing') {
      if (this.hitstop > 0) { this.hitstop -= dt; dt *= 0.12; }
      this.acc += dt;
      let steps = 0;
      while (this.acc >= 1 / 120 && steps < 8) { this.update(1 / 120); this.acc -= 1 / 120; steps++; }
    } else {
      // keep particles alive subtly on menu
      this.acc = 0;
      if (this.state === 'dead') this.updateFx(dt);
    }
    this.render();
    this.hudTick += dt;
    if (this.hudTick > 0.06) { this.hudTick = 0; if (this.state === 'playing') this.pushHud(); }
  };

  updateFx(dt: number) {
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      if (p.life <= 0) { this.parts.splice(i, 1); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.vx *= 1 - 3 * dt; p.vy *= 1 - 3 * dt;
    }
    for (let i = this.floats.length - 1; i >= 0; i--) {
      const f = this.floats[i];
      f.life -= dt; f.y += f.vy * dt; f.vy *= 1 - 2 * dt;
      if (f.life <= 0) this.floats.splice(i, 1);
    }
    this.shake *= 1 - 8 * dt;
    if (this.shake < 0.2) this.shake = 0;
    this.flashW = Math.max(0, this.flashW - dt * 2.4);
  }

  update(dt: number) {
    this.time += dt;
    const S = this.stats;

    // ---- input / movement ----
    let ax = this.input.ax, ay = this.input.ay;
    if (this.input.left) ax -= 1; if (this.input.right) ax += 1;
    if (this.input.up) ay -= 1; if (this.input.down) ay += 1;
    const m = Math.hypot(ax, ay);
    if (m > 1) { ax /= m; ay /= m; }
    const moving = m > 0.08;
    if (moving) this.face = lerp2angle(this.face, Math.atan2(ay, ax), 1 - Math.pow(0.0005, dt));

    const accel = 2600;
    this.pvx += ax * accel * dt; this.pvy += ay * accel * dt;
    const fr = this.dashTimer > 0 ? 2.6 : 9.5;
    this.pvx *= 1 - Math.min(1, fr * dt); this.pvy *= 1 - Math.min(1, fr * dt);
    const maxS = this.dashTimer > 0 ? 1000 : S.speed * (this.hunger <= 0 ? 0.7 : 1);
    const sp = Math.hypot(this.pvx, this.pvy);
    if (sp > maxS) { this.pvx = (this.pvx / sp) * maxS; this.pvy = (this.pvy / sp) * maxS; }
    this.px += this.pvx * dt; this.py += this.pvy * dt;
    this.legPhase += sp * dt * 0.035;

    if (this.dashTimer > 0) {
      this.dashTimer -= dt;
      if (this.parts.length < 400)
        this.parts.push({ x: this.px, y: this.py + 10, vx: rnd(40, -40), vy: rnd(40, -40), life: 0.35, max: 0.35, r: 9, c: '#bff0ff', g: 0 });
    }
    this.dashCharge = Math.min(S.dashCharges, this.dashCharge + dt / 1.5);
    this.attackCd = Math.max(0, this.attackCd - dt);
    this.attackTimer = Math.max(0, this.attackTimer - dt);
    this.iframes = Math.max(0, this.iframes - dt);
    this.hitFlash = Math.max(0, this.hitFlash - dt * 3);
    for (const k in this.cd) this.cd[k] = Math.max(0, this.cd[k] - dt);
    if (this.comboT > 0) { this.comboT -= dt; if (this.comboT <= 0) this.combo = 0; }

    // actions
    if (this.input.attack) this.attack();
    if (this.input.dash) { this.useDash(); this.input.dash = false; }
    if (this.input.skill1) { this.useSkill(0); this.input.skill1 = false; }
    if (this.input.skill2) { this.useSkill(1); this.input.skill2 = false; }

    // ---- tutorial nudges ----
    if (this.level === 1 && this.kills === 0) {
      const slot = Math.floor(this.time);
      if (slot !== this.lastHint && slot % 4 === 1 && this.time < 20) {
        this.lastHint = slot;
        this.float(this.px, this.py - 56, this.time < 9 ? '🌾 WALK INTO GRASS TO GRAZE' : '🐂 HEADBUTT (J / CLICK) PREDATORS', '#ffffff', 1.1);
      }
    }

    // ---- hunger / regen ----
    this.hunger -= dt * (2.1 + this.era * 0.12) * S.metabolism;
    if (this.hunger <= 0) { this.hunger = 0; this.hp -= dt * 7; if (this.hp <= 0) return this.die(); }
    else if (S.regen > 0) this.heal(S.regen * dt);

    // ---- grazing ----
    this.grazing = Math.max(0, this.grazing - dt * 3);
    for (let i = this.foods.length - 1; i >= 0; i--) {
      const f = this.foods[i];
      f.phase += dt;
      const d = Math.hypot(f.x - this.px, f.y - this.py);
      if (d < f.r + 26 * S.size) {
        const eat = Math.min(f.amount, 95 * S.grazeRate * dt);
        f.amount -= eat;
        this.hunger = Math.min(S.maxHunger, this.hunger + eat * 0.26);
        this.addDna(eat * 0.055 * f.dna * 0.14 * S.dnaGain);
        this.grazing = 1;
        if (Math.random() < 0.45 && this.parts.length < 400) {
          const c = f.kind === 3 ? '#ff9a5a' : f.kind === 2 ? '#cfe6f5' : f.kind === 1 ? '#c58bd1' : '#8fe06a';
          this.parts.push({ x: f.x + rnd(16, -16), y: f.y + rnd(10, -10), vx: rnd(60, -60), vy: rnd(-40, -120), life: 0.5, max: 0.5, r: 3, c, g: 0.5 });
        }
        if (f.amount <= 0) {
          this.burst(f.x, f.y, 10, '#8fe06a', 180, 0.5, 3);
          this.float(f.x, f.y - 12, '+' + Math.round(f.dna) + ' DNA', '#b8ff8a', 0.9);
          this.addDna(f.dna * S.dnaGain);
          this.foods.splice(i, 1);
          continue;
        }
      }
      if (Math.hypot(f.x - this.px, f.y - this.py) > 2000) this.foods.splice(i, 1);
    }
    this.foodT -= dt;
    if (this.foodT <= 0 && this.foods.length < 80) { this.foodT = 0.25; this.spawnFood(); }

    // ---- orbs ----
    for (let i = this.orbs.length - 1; i >= 0; i--) {
      const o = this.orbs[i];
      o.life -= dt;
      const dx = this.px - o.x, dy = this.py - o.y, d = Math.hypot(dx, dy) || 1;
      if (d < S.magnet + 40) { o.vx += (dx / d) * 1400 * dt; o.vy += (dy / d) * 1400 * dt; }
      o.x += o.vx * dt; o.y += o.vy * dt;
      o.vx *= 1 - 2.4 * dt; o.vy *= 1 - 2.4 * dt;
      if (d < 28) {
        if (o.kind === 'dna') { this.addDna(o.v * S.dnaGain); }
        else { this.heal(o.v); this.hunger = Math.min(S.maxHunger, this.hunger + o.v * 0.8); this.float(this.px, this.py - 34, '+' + Math.round(o.v) + ' HP', '#ff8fa3'); }
        this.burst(o.x, o.y, 4, o.kind === 'dna' ? '#7dffb2' : '#ff8fa3', 120, 0.3, 2.4);
        this.orbs.splice(i, 1); continue;
      }
      if (o.life <= 0) this.orbs.splice(i, 1);
    }

    // ---- orbit calves ----
    const orbitN = this.owned['storm'] ? this.owned['storm'] + 1 : 0;
    this.orbitAngle += dt * 2.1;
    if (orbitN) {
      for (let i = 0; i < orbitN; i++) {
        const a = this.orbitAngle + (i / orbitN) * TAU;
        const ox = this.px + Math.cos(a) * 92, oy = this.py + Math.sin(a) * 92;
        for (const e of this.enemies) {
          if ((e.x - ox) ** 2 + (e.y - oy) ** 2 < (e.r + 20) ** 2 && e.hit <= 0) {
            this.damageEnemy(e, S.damage * 0.5, Math.cos(a) * 160, Math.sin(a) * 160);
            e.hit = 0.25;
          }
        }
      }
    }

    // ---- enemies ----
    this.spawnT -= dt;
    const target = Math.min(42, 4 + this.era * 2.2 + this.time / 16);
    if (this.spawnT <= 0 && this.enemies.length < target) { this.spawnT = Math.max(0.22, 1.4 - this.era * 0.14); this.spawnEnemy(); }
    this.eliteT -= dt;
    if (this.eliteT <= 0) { this.eliteT = Math.max(18, 44 - this.era * 4); this.spawnEnemy(true); this.float(this.px, this.py - 60, '⚠ ALPHA NEARBY', '#ffb86b', 1.3); }

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.dead) { this.enemies.splice(i, 1); continue; }
      e.hit = Math.max(0, e.hit - dt);
      e.stun = Math.max(0, e.stun - dt);
      e.atkCd = Math.max(0, e.atkCd - dt);
      e.phase += dt * 8;
      if (e.poisonT > 0) {
        e.poisonT -= dt; e.hp -= e.poison * dt;
        if (Math.random() < 0.15 && this.parts.length < 400) this.parts.push({ x: e.x + rnd(14, -14), y: e.y, vx: 0, vy: -40, life: 0.4, max: 0.4, r: 2.5, c: '#a3e635', g: 0 });
        if (e.hp <= 0) { this.killEnemy(e); continue; }
      }
      const dx = this.px - e.x, dy = this.py - e.y, d = Math.hypot(dx, dy) || 1;
      if (d > 2200) { this.enemies.splice(i, 1); continue; }
      if (e.stun <= 0) {
        if (e.type === 'spitter') {
          if (d > 330) { e.vx += (dx / d) * e.speed * 5 * dt; e.vy += (dy / d) * e.speed * 5 * dt; }
          else if (d < 240) { e.vx -= (dx / d) * e.speed * 4 * dt; e.vy -= (dy / d) * e.speed * 4 * dt; }
          if (e.atkCd <= 0 && d < 520) {
            e.atkCd = 2.1;
            this.shots.push({ x: e.x, y: e.y, vx: (dx / d) * 300, vy: (dy / d) * 300, life: 2.2, dmg: e.dmg, friendly: false, r: 8, kind: 'spit' });
          }
        } else if (e.type === 'dodo') {
          const a = Math.atan2(dy, dx) + Math.PI + Math.sin(this.time * 2 + e.phase) * 0.6;
          if (d < 320) { e.vx += Math.cos(a) * e.speed * 4 * dt; e.vy += Math.sin(a) * e.speed * 4 * dt; }
        } else {
          e.vx += (dx / d) * e.speed * 6 * dt; e.vy += (dy / d) * e.speed * 6 * dt;
        }
      }
      e.vx *= 1 - Math.min(1, 6 * dt); e.vy *= 1 - Math.min(1, 6 * dt);
      const es = Math.hypot(e.vx, e.vy);
      const mx = e.speed * (e.stun > 0 ? 3 : 1.05);
      if (es > mx) { e.vx = (e.vx / es) * mx; e.vy = (e.vy / es) * mx; }
      e.x += e.vx * dt; e.y += e.vy * dt;

      // separation
      for (let j = i - 1; j >= 0 && j > i - 5; j--) {
        const o = this.enemies[j];
        const ddx = o.x - e.x, ddy = o.y - e.y, dd = Math.hypot(ddx, ddy) || 1;
        const min = e.r + o.r;
        if (dd < min) {
          const push = (min - dd) * 4 * dt;
          e.x -= (ddx / dd) * push; e.y -= (ddy / dd) * push;
          o.x += (ddx / dd) * push; o.y += (ddy / dd) * push;
        }
      }

      // contact damage
      if (d < e.r + 24 * S.size && e.atkCd <= 0 && e.type !== 'spitter' && e.type !== 'dodo') {
        e.atkCd = 0.9;
        this.hurt(e.dmg, e.x, e.y);
        if (S.thorns > 0) this.damageEnemy(e, S.thorns, -(dx / d) * 200, -(dy / d) * 200);
      }
    }

    // ---- shots ----
    for (let i = this.shots.length - 1; i >= 0; i--) {
      const s = this.shots[i];
      s.life -= dt; s.x += s.vx * dt; s.y += s.vy * dt;
      if (s.kind === 'milk') { s.vx *= 1 - 1.2 * dt; s.vy *= 1 - 1.2 * dt; }
      if (this.parts.length < 420 && Math.random() < 0.6)
        this.parts.push({ x: s.x, y: s.y, vx: 0, vy: 0, life: 0.3, max: 0.3, r: s.r * 0.6, c: s.friendly ? '#ecf6ff' : '#b58bff', g: 0 });
      let hit = false;
      if (s.friendly) {
        for (const e of this.enemies) {
          if ((e.x - s.x) ** 2 + (e.y - s.y) ** 2 < (e.r + s.r) ** 2) { hit = true; break; }
        }
        if (hit || s.life <= 0) {
          // splash
          const R = 86;
          for (const e of this.enemies) {
            const dd = Math.hypot(e.x - s.x, e.y - s.y);
            if (dd < R + e.r) {
              const a = Math.atan2(e.y - s.y, e.x - s.x);
              this.damageEnemy(e, s.dmg, Math.cos(a) * 240, Math.sin(a) * 240);
            }
          }
          this.burst(s.x, s.y, 18, '#f3f8ff', 280, 0.5, 4.5);
          this.doShake(4);
          this.shots.splice(i, 1); continue;
        }
      } else {
        if (Math.hypot(s.x - this.px, s.y - this.py) < 24 * S.size + s.r) {
          this.hurt(s.dmg, s.x, s.y);
          this.burst(s.x, s.y, 10, '#b58bff', 200, 0.4, 3);
          this.shots.splice(i, 1); continue;
        }
        if (s.life <= 0) { this.shots.splice(i, 1); continue; }
      }
    }

    this.updateFx(dt);

    // camera
    const lead = 0.18;
    const tx = this.px + this.pvx * lead, ty = this.py + this.pvy * lead;
    this.camx = lerp(this.camx, tx, 1 - Math.pow(0.0018, dt));
    this.camy = lerp(this.camy, ty, 1 - Math.pow(0.0018, dt));

    if (this.dna >= this.dnaNeed) this.levelUp();
  }

  addDna(v: number) {
    this.dna += v; this.totalDna += v;
  }

  // ---------- render ----------
  render() {
    const ctx = this.ctx;
    const { w, h, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const bi = this.biomeIdx(this.px, this.py);
    const B = BIOMES[bi];
    ctx.fillStyle = B.ground2;
    ctx.fillRect(0, 0, w, h);

    this.shakeA += 0.6;
    const sx = Math.cos(this.shakeA * 1.7) * this.shake, sy = Math.sin(this.shakeA * 2.3) * this.shake;
    const ox = w / 2 - this.camx + sx, oy = h / 2 - this.camy + sy;
    ctx.save();
    ctx.translate(ox, oy);

    const L = this.camx - w / 2 - 100, R = this.camx + w / 2 + 100;
    const T = this.camy - h / 2 - 100, Bm = this.camy + h / 2 + 100;

    // ground tiles
    const CS = 96;
    const x0 = Math.floor(L / CS), x1 = Math.ceil(R / CS), y0 = Math.floor(T / CS), y1 = Math.ceil(Bm / CS);
    for (let gx = x0; gx <= x1; gx++) {
      for (let gy = y0; gy <= y1; gy++) {
        const wx = gx * CS, wy = gy * CS;
        const idx = this.biomeIdx(wx + CS / 2, wy + CS / 2);
        const bb = BIOMES[idx];
        const n = hash2(gx, gy);
        ctx.fillStyle = n > 0.55 ? bb.ground : bb.ground2;
        ctx.fillRect(wx, wy, CS + 1, CS + 1);
        if (n > 0.86) {
          ctx.fillStyle = bb.detail;
          ctx.globalAlpha = 0.5;
          const dx2 = wx + hash2(gx + 7, gy) * CS, dy2 = wy + hash2(gx, gy + 9) * CS;
          ctx.beginPath(); ctx.ellipse(dx2, dy2, 14, 7, 0, 0, TAU); ctx.fill();
          ctx.globalAlpha = 1;
        } else if (n < 0.08) {
          ctx.fillStyle = 'rgba(0,0,0,0.18)';
          const dx2 = wx + hash2(gx + 3, gy) * CS, dy2 = wy + hash2(gx, gy + 5) * CS;
          ctx.beginPath(); ctx.ellipse(dx2, dy2, 9, 6, 0, 0, TAU); ctx.fill();
        }
      }
    }

    // food
    for (const f of this.foods) {
      if (f.x < L || f.x > R || f.y < T || f.y > Bm) continue;
      const k = f.amount / f.max;
      const sway = Math.sin(f.phase * 2 + f.x * 0.01) * 0.18;
      ctx.save(); ctx.translate(f.x, f.y);
      ctx.fillStyle = 'rgba(0,0,0,0.22)';
      ctx.beginPath(); ctx.ellipse(0, 6, 14 * k + 4, 5, 0, 0, TAU); ctx.fill();
      ctx.rotate(sway);
      const cols = ['#7fd14a', '#b76fd1', '#dff1ff', '#ff8a4a'][f.kind];
      const cols2 = ['#4f9c2e', '#7f4a96', '#a8c8dd', '#c74a22'][f.kind];
      if (f.kind === 1) {
        ctx.fillStyle = cols2; ctx.fillRect(-3, -10, 6, 14);
        ctx.fillStyle = cols; ctx.beginPath(); ctx.ellipse(0, -14, 13 * k + 3, 8 * k + 3, 0, 0, TAU); ctx.fill();
      } else {
        for (let i = 0; i < 5; i++) {
          const a = -1.2 + i * 0.6;
          ctx.strokeStyle = i % 2 ? cols2 : cols;
          ctx.lineWidth = 4; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(0, 4); ctx.quadraticCurveTo(Math.sin(a) * 10, -8 * k - 4, Math.sin(a) * 18, -20 * k - 2); ctx.stroke();
        }
      }
      ctx.restore();
    }

    // orbs
    for (const o of this.orbs) {
      const pulse = 1 + Math.sin(this.time * 10 + o.x) * 0.12;
      ctx.fillStyle = o.kind === 'dna' ? '#7dffb2' : '#ff8fa3';
      ctx.shadowBlur = 14; ctx.shadowColor = ctx.fillStyle as string;
      ctx.beginPath(); ctx.arc(o.x, o.y, (o.kind === 'dna' ? 6 : 9) * pulse, 0, TAU); ctx.fill();
      ctx.shadowBlur = 0;
    }

    // enemies
    for (const e of this.enemies) {
      if (e.x < L - 50 || e.x > R + 50 || e.y < T - 50 || e.y > Bm + 50) continue;
      this.drawEnemy(ctx, e);
    }

    // shots
    for (const s of this.shots) {
      ctx.fillStyle = s.friendly ? '#f6fbff' : '#a97cff';
      ctx.shadowBlur = 12; ctx.shadowColor = ctx.fillStyle;
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, TAU); ctx.fill();
      ctx.shadowBlur = 0;
    }

    // orbit calves
    const orbitN = this.owned['storm'] ? this.owned['storm'] + 1 : 0;
    for (let i = 0; i < orbitN; i++) {
      const a = this.orbitAngle + (i / orbitN) * TAU;
      const x = this.px + Math.cos(a) * 92, y = this.py + Math.sin(a) * 92;
      ctx.save(); ctx.translate(x, y);
      ctx.fillStyle = '#c7d2fe'; ctx.shadowBlur = 16; ctx.shadowColor = '#818cf8';
      ctx.beginPath(); ctx.ellipse(0, 0, 13, 10, a, 0, TAU); ctx.fill();
      ctx.fillStyle = '#4338ca'; ctx.beginPath(); ctx.arc(Math.cos(a) * 7, Math.sin(a) * 7, 5, 0, TAU); ctx.fill();
      ctx.shadowBlur = 0; ctx.restore();
    }

    if (this.state !== 'dead') this.drawCow(ctx);

    // particles
    for (const p of this.parts) {
      const k = p.life / p.max;
      ctx.globalAlpha = Math.min(1, k * 1.6);
      ctx.fillStyle = p.c;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * (0.4 + k * 0.8), 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;

    // floaters
    ctx.textAlign = 'center';
    for (const f of this.floats) {
      ctx.globalAlpha = Math.min(1, f.life * 1.8);
      ctx.font = `800 ${Math.round(16 * f.s)}px ui-rounded, system-ui, sans-serif`;
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,0.55)';
      ctx.strokeText(f.text, f.x, f.y); ctx.fillStyle = f.c; ctx.fillText(f.text, f.x, f.y);
    }
    ctx.globalAlpha = 1;

    // offscreen enemy markers
    for (const e of this.enemies) {
      if (e.x > L && e.x < R && e.y > T && e.y < Bm) continue;
      const a = Math.atan2(e.y - this.camy, e.x - this.camx);
      const rx = this.camx + Math.cos(a) * Math.min(w, h) * 0.42;
      const ry = this.camy + Math.sin(a) * Math.min(w, h) * 0.42;
      ctx.save(); ctx.translate(rx, ry); ctx.rotate(a);
      ctx.globalAlpha = 0.55; ctx.fillStyle = e.elite ? '#ffb86b' : e.color;
      ctx.beginPath(); ctx.moveTo(9, 0); ctx.lineTo(-7, 6); ctx.lineTo(-7, -6); ctx.closePath(); ctx.fill();
      ctx.restore(); ctx.globalAlpha = 1;
    }

    ctx.restore();

    // day/night + vignette
    const dayT = (this.time % 100) / 100;
    const night = Math.max(0, Math.sin(dayT * TAU - Math.PI / 2)) * 0.42;
    if (night > 0.01) { ctx.fillStyle = `rgba(14,22,58,${night})`; ctx.fillRect(0, 0, w, h); }

    const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.32, w / 2, h / 2, Math.max(w, h) * 0.72);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, `rgba(${this.hunger <= 0 ? '60,0,0' : '0,0,0'},0.55)`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

    if (this.hitFlash > 0) { ctx.fillStyle = `rgba(255,40,40,${this.hitFlash * 0.35})`; ctx.fillRect(0, 0, w, h); }
    if (this.flashW > 0) { ctx.fillStyle = `rgba(255,255,255,${this.flashW * 0.4})`; ctx.fillRect(0, 0, w, h); }
    this.flashW = Math.max(0, this.flashW - 0.04);
  }

  drawEnemy(ctx: CanvasRenderingContext2D, e: Enemy) {
    const bob = Math.sin(e.phase) * 2;
    ctx.save();
    ctx.translate(e.x, e.y + bob);
    ctx.fillStyle = 'rgba(0,0,0,0.25)';
    ctx.beginPath(); ctx.ellipse(0, e.r * 0.75 - bob, e.r * 0.9, e.r * 0.35, 0, 0, TAU); ctx.fill();
    const dir = Math.atan2(this.py - e.y, this.px - e.x);
    const flip = Math.cos(dir) < 0 ? -1 : 1;
    ctx.scale(flip, 1);
    const col = e.hit > 0 ? '#ffffff' : e.color;
    if (e.elite) { ctx.shadowBlur = 20; ctx.shadowColor = '#ffb86b'; }

    if (e.type === 'bug') {
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.ellipse(0, 0, e.r, e.r * 0.72, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.4)'; ctx.lineWidth = 2;
      for (let i = -1; i <= 1; i += 2) {
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(i * e.r * 1.3, Math.sin(e.phase + i) * e.r); ctx.stroke();
      }
      ctx.fillStyle = '#1b2a12'; ctx.beginPath(); ctx.arc(e.r * 0.5, -3, 3, 0, TAU); ctx.fill();
    } else if (e.type === 'spitter') {
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.ellipse(0, 0, e.r * 0.9, e.r, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#2a1b4a';
      ctx.beginPath(); ctx.arc(e.r * 0.4, -e.r * 0.3, 4, 0, TAU); ctx.fill();
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.ellipse(e.r * 0.8, 0, e.r * 0.45, e.r * 0.35, 0, 0, TAU); ctx.fill();
    } else {
      // quadruped / biped predator
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.ellipse(0, 0, e.r * 1.05, e.r * 0.68, 0, 0, TAU); ctx.fill();
      // legs
      ctx.strokeStyle = col; ctx.lineWidth = Math.max(3, e.r * 0.22); ctx.lineCap = 'round';
      for (let i = -1; i <= 1; i += 2) {
        ctx.beginPath(); ctx.moveTo(i * e.r * 0.5, e.r * 0.3);
        ctx.lineTo(i * e.r * 0.5 + Math.sin(e.phase + i * 2) * e.r * 0.4, e.r * 0.95); ctx.stroke();
      }
      // head
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.ellipse(e.r * 0.95, -e.r * 0.45, e.r * 0.5, e.r * 0.38, 0.3, 0, TAU); ctx.fill();
      // eye + teeth
      ctx.fillStyle = '#20100c'; ctx.beginPath(); ctx.arc(e.r * 1.05, -e.r * 0.55, 2.6, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.moveTo(e.r * 1.3, -e.r * 0.3); ctx.lineTo(e.r * 1.15, -e.r * 0.05); ctx.lineTo(e.r * 1.38, -e.r * 0.12); ctx.fill();
      if (e.type === 'sabre' || e.type === 'yeti') {
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.moveTo(e.r * 1.1, -e.r * 0.2); ctx.lineTo(e.r * 1.0, e.r * 0.35); ctx.lineTo(e.r * 1.2, -e.r * 0.15); ctx.fill();
      }
      // tail
      ctx.strokeStyle = col; ctx.lineWidth = e.r * 0.26;
      ctx.beginPath(); ctx.moveTo(-e.r * 0.9, -e.r * 0.1);
      ctx.quadraticCurveTo(-e.r * 1.5, -e.r * 0.3 + Math.sin(e.phase) * 5, -e.r * 1.9, -e.r * 0.55); ctx.stroke();
    }
    ctx.shadowBlur = 0;
    ctx.restore();

    // hp bar
    if (e.hp < e.maxHp) {
      const w2 = e.r * 2;
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.fillRect(e.x - w2 / 2, e.y - e.r - 14, w2, 5);
      ctx.fillStyle = e.elite ? '#ffb86b' : '#ff6b6b';
      ctx.fillRect(e.x - w2 / 2, e.y - e.r - 14, w2 * clamp(e.hp / e.maxHp, 0, 1), 5);
    }
  }

  drawCow(ctx: CanvasRenderingContext2D) {
    const S = this.stats;
    const sz = 1 * S.size;
    const sp = Math.hypot(this.pvx, this.pvy);
    const bounce = Math.sin(this.legPhase * 2) * Math.min(sp / 260, 1) * 3;
    const squash = 1 + Math.sin(this.legPhase * 2) * Math.min(sp / 400, 1) * 0.06 + (this.attackTimer > 0 ? 0.12 : 0);
    ctx.save();
    ctx.translate(this.px, this.py - bounce);
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath(); ctx.ellipse(0, 20 * sz + bounce, 26 * sz, 9 * sz, 0, 0, TAU); ctx.fill();

    const flip = Math.cos(this.face) < -0.05 ? -1 : 1;
    ctx.scale(flip * sz * squash, sz * (2 - squash));
    if (this.iframes > 0 && Math.floor(this.time * 20) % 2 === 0) ctx.globalAlpha = 0.6;

    const glow = this.visuals['glow'] || 0;
    if (glow) { ctx.shadowBlur = 10 + glow * 5; ctx.shadowColor = this.owned['venom'] ? '#a3e635' : '#86efac'; }

    const hide = '#f7f3ec';
    const spot = '#2b2b33';

    // legs
    ctx.strokeStyle = '#e8e2d7'; ctx.lineWidth = 7; ctx.lineCap = 'round';
    for (let i = 0; i < 4; i++) {
      const bx = -14 + (i % 2) * 26 + (i < 2 ? 0 : 3);
      const ph = this.legPhase + i * 1.6;
      const kick = Math.sin(ph) * Math.min(sp / 200, 1) * 9;
      ctx.beginPath(); ctx.moveTo(bx, 8); ctx.lineTo(bx + kick, 22); ctx.stroke();
    }
    // tail
    ctx.strokeStyle = '#e8e2d7'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(-24, -4);
    ctx.quadraticCurveTo(-36, -2 + Math.sin(this.legPhase) * 5, -34, 12); ctx.stroke();
    ctx.fillStyle = spot; ctx.beginPath(); ctx.arc(-34, 14, 4, 0, TAU); ctx.fill();

    // mane (mammoth)
    if (this.visuals['mane']) {
      ctx.fillStyle = '#b9794a';
      ctx.beginPath(); ctx.ellipse(-4, -6, 30, 18, 0, 0, TAU); ctx.fill();
    }

    // body
    ctx.fillStyle = hide;
    ctx.beginPath(); ctx.ellipse(0, 0, 27, 17, 0, 0, TAU); ctx.fill();
    // spots
    ctx.fillStyle = spot;
    ctx.beginPath(); ctx.ellipse(-9, -3, 9, 6.5, 0.4, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(8, 5, 6.5, 4.5, -0.3, 0, TAU); ctx.fill();
    // plates
    if (this.visuals['plates']) {
      ctx.strokeStyle = '#9fb0c4'; ctx.lineWidth = 3;
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath(); ctx.arc(i * 11, 0, 11, -2.6, -0.5); ctx.stroke();
      }
    }
    // spikes
    const spikes = this.visuals['spikes'] || 0;
    if (spikes) {
      ctx.fillStyle = '#fdf0c2';
      for (let i = 0; i < 3 + spikes; i++) {
        const t = i / (2 + spikes);
        const x = -20 + t * 40;
        const hgt = 9 + spikes * 2;
        ctx.beginPath(); ctx.moveTo(x - 4, -14); ctx.lineTo(x, -14 - hgt); ctx.lineTo(x + 4, -14); ctx.fill();
      }
    }
    if (this.visuals['flowers']) {
      for (let i = 0; i < 3; i++) {
        ctx.fillStyle = ['#f472b6', '#facc15', '#f9a8d4'][i];
        ctx.beginPath(); ctx.arc(-14 + i * 13, -12 + Math.sin(this.time * 2 + i) * 1.5, 3.4, 0, TAU); ctx.fill();
      }
    }
    // udder
    ctx.fillStyle = '#ffc7cf';
    ctx.beginPath(); ctx.ellipse(-6, 13, 7, 5, 0, 0, TAU); ctx.fill();

    // head
    const lunge = this.attackTimer > 0 ? 8 : 0;
    ctx.save();
    ctx.translate(26 + lunge, -6 + Math.sin(this.legPhase) * 1.2);
    ctx.rotate(this.attackTimer > 0 ? 0.4 : 0);
    ctx.fillStyle = hide;
    ctx.beginPath(); ctx.ellipse(0, 0, 14, 11, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = spot;
    ctx.beginPath(); ctx.ellipse(-4, -5, 6, 4, 0.3, 0, TAU); ctx.fill();
    // snout
    ctx.fillStyle = '#ffc7cf';
    ctx.beginPath(); ctx.ellipse(9, 3, 7, 6, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#e39aa6';
    ctx.beginPath(); ctx.arc(7, 2, 1.6, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(12, 3, 1.6, 0, TAU); ctx.fill();
    // eye
    ctx.fillStyle = '#20202a';
    ctx.beginPath(); ctx.arc(5, -5, 2.6, 0, TAU); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(5.9, -5.9, 1, 0, TAU); ctx.fill();
    // ears
    ctx.fillStyle = '#ded6c9';
    ctx.beginPath(); ctx.ellipse(-10, -6, 6, 3.4, -0.5, 0, TAU); ctx.fill();
    // horns
    const hs = S.horn;
    ctx.strokeStyle = '#f2e3bd'; ctx.lineWidth = 4 * Math.min(hs, 2.4); ctx.lineCap = 'round';
    for (let i = -1; i <= 1; i += 2) {
      ctx.beginPath();
      ctx.moveTo(-2, -9);
      ctx.quadraticCurveTo(2 + 8 * hs, -14 - 6 * hs, 6 + 13 * hs * (i > 0 ? 1 : 0.7), -8 - 10 * hs);
      ctx.stroke();
    }
    ctx.restore();

    ctx.restore();

    // attack arc
    if (this.attackTimer > 0) {
      const k = this.attackTimer / 0.2;
      const reach = 54 * S.size + S.horn * 14;
      ctx.save();
      ctx.translate(this.px, this.py);
      ctx.rotate(this.face);
      ctx.globalAlpha = k * 0.6;
      ctx.strokeStyle = '#fff6cf'; ctx.lineWidth = 7 * k;
      ctx.beginPath(); ctx.arc(0, 0, reach * (1.3 - k * 0.3), -0.8, 0.8); ctx.stroke();
      ctx.restore(); ctx.globalAlpha = 1;
    }
  }

  pushHud() {
    const list = this.abilities.filter((a) => a !== 'dash');
    const names: Record<string, [string, string, number]> = {
      mortar: ['Milk Mortar', '🥛', 1.5],
      stomp: ['Seismic Stomp', '💥', 3.2],
    };
    const ab = [
      { key: 'dash', name: 'Stampede', icon: '💨', ready: Math.min(1, this.dashCharge), charges: Math.floor(this.dashCharge), maxCharges: this.stats.dashCharges },
      ...list.map((k) => ({
        key: k, name: names[k]?.[0] || k, icon: names[k]?.[1] || '✦',
        ready: 1 - (this.cd[k] || 0) / (names[k]?.[2] || 1), charges: (this.cd[k] || 0) > 0 ? 0 : 1, maxCharges: 1,
      })),
    ];
    this.onHud({
      state: this.state, hp: this.hp, maxHp: this.stats.maxHp, hunger: this.hunger, maxHunger: this.stats.maxHunger,
      dna: this.dna, dnaNeed: this.dnaNeed, level: this.level, score: this.score, time: this.time,
      era: this.era, eraName: ERAS[Math.min(ERAS.length - 1, this.era - 1)], biome: BIOMES[this.biomeIdx(this.px, this.py)].name,
      kills: this.kills, abilities: ab, choices: this.choices, combo: this.combo,
      traits: Object.keys(this.owned).map((k) => {
        const d = MUTATIONS.find((m) => m.key === k)!;
        return { name: d.name, icon: d.icon, tier: this.owned[k], color: d.color };
      }),
    });
  }

  mount() { if (!this.running) { this.running = true; this.last = 0; this.raf = requestAnimationFrame(this.loop); } }
  unmount() { this.running = false; cancelAnimationFrame(this.raf); }
}

function lerp2angle(a: number, b: number, t: number) {
  let d = ((b - a + Math.PI * 3) % TAU) - Math.PI;
  return a + d * t;
}
