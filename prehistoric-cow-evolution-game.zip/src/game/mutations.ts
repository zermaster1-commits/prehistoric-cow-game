export type Stats = {
  maxHp: number;
  armor: number;
  damage: number;
  speed: number;
  maxHunger: number;
  metabolism: number; // hunger drain multiplier
  grazeRate: number;
  dnaGain: number;
  regen: number;
  size: number;
  horn: number;
  thorns: number;
  lifesteal: number;
  crit: number;
  magnet: number;
  knockback: number;
  poison: number;
  dashCharges: number;
  atkSpeed: number;
};

export const baseStats = (): Stats => ({
  maxHp: 100,
  armor: 0,
  damage: 16,
  speed: 210,
  maxHunger: 100,
  metabolism: 1,
  grazeRate: 1,
  dnaGain: 1,
  regen: 0.4,
  size: 1,
  horn: 1,
  thorns: 0,
  lifesteal: 0,
  crit: 0.03,
  magnet: 55,
  knockback: 1,
  poison: 0,
  dashCharges: 1,
  atkSpeed: 1,
});

export type MutationDef = {
  key: string;
  name: string;
  icon: string;
  color: string;
  branch: string;
  desc: (t: number) => string;
  apply: (s: Stats, t: number) => void;
  grants?: string; // ability key
  visual?: string;
};

export const MUTATIONS: MutationDef[] = [
  {
    key: 'hooves',
    name: 'Thunder Hooves',
    icon: '🦵',
    color: '#67e8f9',
    branch: 'SWIFT',
    desc: (t) => `+${10 + t * 2}% move speed, +${5 * t}% knockback`,
    apply: (s, t) => {
      s.speed *= 1 + (10 + t * 2) / 100;
      s.knockback += 0.05 * t;
    },
  },
  {
    key: 'hide',
    name: 'Iron Hide',
    icon: '🛡️',
    color: '#94a3b8',
    branch: 'TANK',
    desc: (t) => `+${4 + t} armor, +${18 + t * 4} max health`,
    apply: (s, t) => {
      s.armor += 4 + t;
      s.maxHp += 18 + t * 4;
    },
    visual: 'plates',
  },
  {
    key: 'horns',
    name: 'Gore Horns',
    icon: '🐂',
    color: '#fbbf24',
    branch: 'PREDATOR',
    desc: (t) => `+${22 + t * 4}% headbutt damage, bigger horns`,
    apply: (s, t) => {
      s.damage *= 1 + (22 + t * 4) / 100;
      s.horn += 0.35;
    },
    visual: 'horns',
  },
  {
    key: 'stomach',
    name: 'Second Stomach',
    icon: '🌾',
    color: '#a3e635',
    branch: 'GRAZER',
    desc: (_t) => `+${30}% graze speed, +${15} max fullness, slower hunger`,
    apply: (s) => {
      s.grazeRate *= 1.3;
      s.maxHunger += 15;
      s.metabolism *= 0.88;
    },
  },
  {
    key: 'spikes',
    name: 'Bone Spikes',
    icon: '🦴',
    color: '#fde68a',
    branch: 'TANK',
    desc: (t) => `Attackers take ${8 + t * 5} thorn damage`,
    apply: (s, t) => {
      s.thorns += 8 + t * 5;
    },
    visual: 'spikes',
  },
  {
    key: 'chloro',
    name: 'Chlorophyll Hide',
    icon: '🌞',
    color: '#4ade80',
    branch: 'GRAZER',
    desc: (t) => `Regenerate +${1.2 * t + 1} HP/s, brighter in daylight`,
    apply: (s, t) => {
      s.regen += 1.2 * t + 1;
    },
    visual: 'glow',
  },
  {
    key: 'blood',
    name: 'Crimson Rumen',
    icon: '🩸',
    color: '#f87171',
    branch: 'PREDATOR',
    desc: (t) => `Heal ${10 + t * 5}% of damage dealt`,
    apply: (s, t) => {
      s.lifesteal += (10 + t * 5) / 100;
    },
  },
  {
    key: 'jets',
    name: 'Rumen Jets',
    icon: '💨',
    color: '#38bdf8',
    branch: 'SWIFT',
    desc: (t) => (t === 1 ? 'Gain an extra DASH charge, faster recharge' : '+1 dash charge, +speed'),
    apply: (s) => {
      s.dashCharges += 1;
      s.speed *= 1.05;
    },
    grants: 'dash',
  },
  {
    key: 'mortar',
    name: 'Milk Mortar',
    icon: '🥛',
    color: '#e2e8f0',
    branch: 'ARTILLERY',
    desc: (t) => (t === 1 ? 'NEW SKILL: lob exploding milk globs' : `Milk Mortar +${t * 25}% damage`),
    apply: (_s) => {},
    grants: 'mortar',
  },
  {
    key: 'stomp',
    name: 'Seismic Stomp',
    icon: '💥',
    color: '#fb923c',
    branch: 'TANK',
    desc: (t) => (t === 1 ? 'NEW SKILL: shockwave that flings predators' : `Stomp +${t * 30}% radius & damage`),
    apply: (_s) => {},
    grants: 'stomp',
  },
  {
    key: 'eyes',
    name: 'Compound Eyes',
    icon: '👁️',
    color: '#c084fc',
    branch: 'SWIFT',
    desc: (t) => `+${60 + t * 10} pickup magnetism, +${8}% DNA gain`,
    apply: (s, t) => {
      s.magnet += 60 + t * 10;
      s.dnaGain *= 1.08;
    },
  },
  {
    key: 'venom',
    name: 'Venom Glands',
    icon: '☠️',
    color: '#a3e635',
    branch: 'PREDATOR',
    desc: (t) => `Headbutts poison for ${6 + t * 4} dmg/s`,
    apply: (s, t) => {
      s.poison += 6 + t * 4;
    },
    visual: 'glow',
  },
  {
    key: 'mammoth',
    name: 'Mammoth Growth',
    icon: '🦣',
    color: '#d6a07a',
    branch: 'TANK',
    desc: (_t) => `+${20}% size, +${25} HP, +${15}% damage, -5% speed`,
    apply: (s) => {
      s.size *= 1.2;
      s.maxHp += 25;
      s.damage *= 1.15;
      s.speed *= 0.95;
    },
    visual: 'mane',
  },
  {
    key: 'adrenal',
    name: 'Adrenal Burst',
    icon: '⚡',
    color: '#facc15',
    branch: 'PREDATOR',
    desc: (t) => `+${12 + t * 3}% crit chance, +${15}% attack speed`,
    apply: (s, t) => {
      s.crit += (12 + t * 3) / 100;
      s.atkSpeed *= 1.15;
    },
  },
  {
    key: 'symbiote',
    name: 'Symbiotic Flora',
    icon: '🌺',
    color: '#f472b6',
    branch: 'GRAZER',
    desc: (_t) => `+${25}% DNA from everything, +1 HP/s`,
    apply: (s) => {
      s.dnaGain *= 1.25;
      s.regen += 1;
    },
    visual: 'flowers',
  },
  {
    key: 'storm',
    name: 'Static Udder',
    icon: '🌩️',
    color: '#818cf8',
    branch: 'ARTILLERY',
    desc: (t) => (t === 1 ? 'NEW SKILL: orbiting lightning calves' : `+1 lightning calf (${t + 1} total)`),
    apply: (_s) => {},
    grants: 'orbit',
  },
];

export function pickChoices(_level: number, owned: Record<string, number>, rand: () => number): { def: MutationDef; tier: number }[] {
  const pool = [...MUTATIONS];
  // bias toward branches already invested in, but keep variety
  const out: { def: MutationDef; tier: number }[] = [];
  for (let i = 0; i < 3 && pool.length; i++) {
    const weights = pool.map((d) => {
      const t = owned[d.key] || 0;
      let w = 1;
      if (t > 0) w += 0.6;
      if (t >= 4) w *= 0.5;
      return w;
    });
    let total = weights.reduce((a, b) => a + b, 0);
    let r = rand() * total;
    let idx = 0;
    for (let j = 0; j < pool.length; j++) {
      r -= weights[j];
      if (r <= 0) {
        idx = j;
        break;
      }
    }
    const def = pool.splice(idx, 1)[0];
    out.push({ def, tier: (owned[def.key] || 0) + 1 });
  }
  return out;
}
