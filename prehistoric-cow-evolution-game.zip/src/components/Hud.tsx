import type { Hud } from '../game/engine';

const Bar = ({ v, max, from, to, label, icon }: { v: number; max: number; from: string; to: string; label: string; icon: string }) => (
  <div className="relative h-5 w-full overflow-hidden rounded-full border border-black/40 bg-black/50 shadow-[inset_0_2px_6px_rgba(0,0,0,.6)]">
    <div
      className="h-full rounded-full transition-[width] duration-150 ease-out"
      style={{ width: `${Math.max(0, Math.min(100, (v / max) * 100))}%`, background: `linear-gradient(90deg, ${from}, ${to})` }}
    />
    <div className="absolute inset-0 flex items-center justify-between px-2 text-[10px] font-bold tracking-wider text-white/90 drop-shadow">
      <span>{icon} {label}</span>
      <span>{Math.ceil(v)}/{Math.ceil(max)}</span>
    </div>
  </div>
);

export default function HudView({ hud }: { hud: Hud }) {
  const time = `${Math.floor(hud.time / 60)}:${String(Math.floor(hud.time % 60)).padStart(2, '0')}`;
  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* top-left stats */}
      <div className="absolute left-3 top-3 w-[min(46vw,280px)] space-y-1.5">
        <Bar v={hud.hp} max={hud.maxHp} from="#f43f5e" to="#fb7185" label="HEALTH" icon="❤" />
        <Bar v={hud.hunger} max={hud.maxHunger} from="#d97706" to="#fbbf24" label="FULLNESS" icon="🌾" />
        <div className="relative h-4 w-full overflow-hidden rounded-full border border-black/40 bg-black/50">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-lime-300 transition-[width] duration-100"
            style={{ width: `${Math.min(100, (hud.dna / hud.dnaNeed) * 100)}%` }}
          />
          <div className="absolute inset-0 flex items-center justify-between px-2 text-[10px] font-bold tracking-wider text-white/90">
            <span>🧬 EVOLUTION</span>
            <span>LV {hud.level}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-1 pt-0.5">
          {hud.traits.map((t) => (
            <div
              key={t.name}
              className="flex items-center gap-1 rounded-md border border-white/10 bg-black/50 px-1.5 py-0.5 text-[10px] font-bold text-white/80"
              style={{ boxShadow: `inset 0 0 0 1px ${t.color}22` }}
              title={t.name}
            >
              <span>{t.icon}</span>
              <span style={{ color: t.color }}>{t.tier}</span>
            </div>
          ))}
        </div>
      </div>

      {/* top-right */}
      <div className="absolute right-3 top-3 text-right">
        <div className="font-mono text-2xl font-black tabular-nums text-amber-200 drop-shadow-[0_2px_0_rgba(0,0,0,.6)] sm:text-3xl">
          {hud.score.toLocaleString()}
        </div>
        <div className="text-[11px] font-bold uppercase tracking-widest text-white/60">{hud.eraName} · {time}</div>
        <div className="text-[11px] font-semibold text-emerald-300/80">{hud.biome}</div>
        {hud.combo > 1 && (
          <div
            key={hud.combo}
            className="mt-1 animate-[pop_.3s_ease-out] text-lg font-black text-orange-300 drop-shadow"
          >
            {hud.combo}× COMBO
          </div>
        )}
      </div>

      {/* abilities */}
      <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-2">
        {hud.abilities.map((a, i) => (
          <div
            key={a.key}
            className="relative h-12 w-12 overflow-hidden rounded-xl border-2 border-white/15 bg-black/60 text-center shadow-lg"
          >
            <div className="absolute inset-0 flex items-center justify-center text-xl">{a.icon}</div>
            <div
              className="absolute inset-x-0 bottom-0 bg-white/15 transition-[height] duration-75"
              style={{ height: `${(1 - Math.min(1, Math.max(0, a.ready))) * 100}%` }}
            />
            <div className="absolute bottom-0 right-0.5 text-[9px] font-black text-white/70">
              {a.key === 'dash' ? `${a.charges}/${a.maxCharges}` : ['Q', 'E'][i - 1] ?? ''}
            </div>
            {a.key === 'dash' && <div className="absolute bottom-0 left-0.5 text-[9px] font-black text-white/50">SPC</div>}
          </div>
        ))}
      </div>
    </div>
  );
}
