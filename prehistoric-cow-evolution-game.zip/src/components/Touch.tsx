import { useRef, useState } from 'react';
import type { Input } from '../game/engine';

export default function TouchControls({ input, onSkill }: { input: Input; onSkill: (i: number) => void; }) {
  const base = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0, active: false });

  const move = (e: React.PointerEvent) => {
    const el = base.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    let dx = e.clientX - cx, dy = e.clientY - cy;
    const max = r.width / 2;
    const d = Math.hypot(dx, dy);
    if (d > max) { dx = (dx / d) * max; dy = (dy / d) * max; }
    input.ax = dx / max; input.ay = dy / max;
    setKnob({ x: dx, y: dy, active: true });
  };
  const end = () => { input.ax = 0; input.ay = 0; setKnob({ x: 0, y: 0, active: false }); };

  const Btn = ({ label, icon, cls, onDown, onUp }: any) => (
    <button
      onPointerDown={(e) => { e.preventDefault(); (e.target as HTMLElement).setPointerCapture(e.pointerId); onDown(); }}
      onPointerUp={(e) => { e.preventDefault(); onUp?.(); }}
      onPointerCancel={() => onUp?.()}
      className={`flex touch-none select-none flex-col items-center justify-center rounded-full border-2 border-white/20 text-white/90 shadow-lg backdrop-blur-sm active:scale-95 active:brightness-150 ${cls}`}
    >
      <span className="text-xl leading-none">{icon}</span>
      <span className="text-[8px] font-black tracking-wider">{label}</span>
    </button>
  );

  return (
    <div className="pointer-events-none absolute inset-0 z-20 md:hidden">
      <div
        ref={base}
        onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture(e.pointerId); move(e); }}
        onPointerMove={(e) => { if (e.buttons || knob.active) move(e); }}
        onPointerUp={end}
        onPointerCancel={end}
        className="pointer-events-auto absolute bottom-6 left-5 h-32 w-32 touch-none rounded-full border-2 border-white/15 bg-black/30 backdrop-blur-sm"
      >
        <div
          className="absolute left-1/2 top-1/2 h-14 w-14 rounded-full border-2 border-white/40 bg-white/25"
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
        />
      </div>
      <div className="pointer-events-auto absolute bottom-6 right-5 grid grid-cols-2 gap-3">
        <Btn label="SKILL" icon="✦" cls="h-14 w-14 bg-violet-600/50" onDown={() => onSkill(0)} />
        <Btn label="HEADBUTT" icon="🐂" cls="h-20 w-20 bg-amber-500/50" onDown={() => (input.attack = true)} onUp={() => (input.attack = false)} />
        <Btn label="SKILL2" icon="✧" cls="h-14 w-14 bg-fuchsia-600/50" onDown={() => onSkill(1)} />
        <Btn label="DASH" icon="💨" cls="h-16 w-16 bg-sky-500/50" onDown={() => (input.dash = true)} />
      </div>
    </div>
  );
}
