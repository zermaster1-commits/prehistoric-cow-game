import { useEffect, useRef, useState, useCallback } from 'react';
import { Game, type Hud } from './game/engine';
import HudView from './components/Hud';
import TouchControls from './components/Touch';

type ScoreRow = { score: number; level: number; time: number; kills: number; date: string };
const KEY = 'moolithic.scores.v1';

function loadScores(): ScoreRow[] {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; }
}
function saveScore(r: ScoreRow): ScoreRow[] {
  const list = [...loadScores(), r].sort((a, b) => b.score - a.score).slice(0, 8);
  localStorage.setItem(KEY, JSON.stringify(list));
  return list;
}

const fmtTime = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [hud, setHud] = useState<Hud | null>(null);
  const [scores, setScores] = useState<ScoreRow[]>(() => loadScores());
  const savedRef = useRef(false);

  useEffect(() => {
    const g = new Game(canvasRef.current!);
    gameRef.current = g;
    g.onHud = (h) => setHud({ ...h });
    g.start();
    g.state = 'menu';
    g.pushHud();
    g.mount();

    const onResize = () => g.resize();
    window.addEventListener('resize', onResize);

    const keymap: Record<string, keyof typeof g.input> = {
      KeyW: 'up', ArrowUp: 'up', KeyS: 'down', ArrowDown: 'down',
      KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right',
    };
    const down = (e: KeyboardEvent) => {
      if (keymap[e.code]) { (g.input as any)[keymap[e.code]] = true; e.preventDefault(); }
      if (e.code === 'Space') { g.input.dash = true; e.preventDefault(); }
      if (e.code === 'KeyJ' || e.code === 'KeyK' || e.code === 'ShiftLeft') g.input.attack = true;
      if (e.code === 'KeyQ') g.input.skill1 = true;
      if (e.code === 'KeyE') g.input.skill2 = true;
      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (g.state === 'playing') g.state = 'paused';
        else if (g.state === 'paused') g.state = 'playing';
        g.pushHud();
      }
      if (e.code === 'Enter') {
        if (g.state === 'menu' || g.state === 'dead') startGame();
      }
      if (g.state === 'evolve' && ['Digit1', 'Digit2', 'Digit3'].includes(e.code)) {
        g.choose(Number(e.code.slice(5)) - 1);
      }
    };
    const up = (e: KeyboardEvent) => {
      if (keymap[e.code]) (g.input as any)[keymap[e.code]] = false;
      if (e.code === 'KeyJ' || e.code === 'KeyK' || e.code === 'ShiftLeft') g.input.attack = false;
    };
    const blur = () => { g.input.up = g.input.down = g.input.left = g.input.right = g.input.attack = false; g.input.ax = g.input.ay = 0; };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);

    const cv = canvasRef.current!;
    const mdown = (e: MouseEvent) => { if (e.button === 0) g.input.attack = true; };
    const mup = () => (g.input.attack = false);
    cv.addEventListener('mousedown', mdown);
    window.addEventListener('mouseup', mup);

    return () => {
      g.unmount();
      window.removeEventListener('resize', onResize);
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
      cv.removeEventListener('mousedown', mdown);
      window.removeEventListener('mouseup', mup);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // persist score on death
  useEffect(() => {
    if (hud?.state === 'dead' && !savedRef.current) {
      savedRef.current = true;
      setScores(saveScore({ score: hud.score, level: hud.level, time: hud.time, kills: hud.kills, date: new Date().toLocaleDateString() }));
    }
  }, [hud?.state]);

  const startGame = useCallback(() => {
    savedRef.current = false;
    gameRef.current?.start();
  }, []);

  const g = gameRef.current;
  const state = hud?.state ?? 'menu';
  const best = scores[0]?.score ?? 0;

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-[#1b2a1f] font-sans text-white select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />

      {hud && state !== 'menu' && <HudView hud={hud} />}

      {g && state !== 'menu' && state !== 'dead' && (
        <TouchControls input={g.input} onSkill={(i) => { if (i === 0) g.input.skill1 = true; else g.input.skill2 = true; }} />
      )}

      {/* pause button */}
      {state === 'playing' && (
        <button
          onClick={() => { if (g) { g.state = 'paused'; g.pushHud(); } }}
          className="absolute right-3 top-24 z-30 rounded-lg border border-white/20 bg-black/50 px-3 py-1.5 text-xs font-bold tracking-wider backdrop-blur active:scale-95 sm:top-28"
        >
          ❚❚ PAUSE
        </button>
      )}

      {/* ---------- MENU ---------- */}
      {state === 'menu' && (
        <Overlay>
          <div className="w-[min(92vw,560px)] rounded-3xl border border-lime-400/25 bg-[#0d150f]/85 p-7 text-center shadow-2xl backdrop-blur-md">
            <div className="text-6xl drop-shadow-[0_0_24px_rgba(132,204,22,.5)]">🐄</div>
            <h1 className="mt-1 bg-gradient-to-b from-lime-200 to-emerald-500 bg-clip-text text-4xl font-black tracking-tight text-transparent sm:text-5xl">
              MOOLITHIC
            </h1>
            <p className="mt-1 text-xs font-bold uppercase tracking-[0.3em] text-lime-200/60">Evolve or be eaten</p>
            <p className="mx-auto mt-4 max-w-sm text-sm leading-relaxed text-white/70">
              You are a dairy cow stranded in the Stone Age. <b className="text-lime-300">Graze</b> to grow DNA,
              <b className="text-amber-300"> headbutt</b> predators, and <b className="text-emerald-300">mutate</b> down
              endless evolutionary paths. The world never ends. Neither does the hunger.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-2 text-left text-[11px] text-white/60 sm:grid-cols-4">
              <Key k="WASD / ⬅➡" v="Move" />
              <Key k="J / Click" v="Headbutt" />
              <Key k="SPACE" v="Stampede" />
              <Key k="Q / E" v="Skills" />
            </div>
            <button
              onClick={startGame}
              className="mt-6 w-full rounded-2xl bg-gradient-to-b from-lime-400 to-emerald-600 px-8 py-4 text-xl font-black tracking-wide text-[#0d150f] shadow-[0_6px_0_#14532d] transition active:translate-y-1 active:shadow-[0_2px_0_#14532d]"
            >
              ▶ BEGIN EVOLUTION
            </button>
            {best > 0 && <p className="mt-3 text-xs font-bold text-amber-200/80">🏆 Best score: {best.toLocaleString()}</p>}
            <p className="mt-1 text-[10px] text-white/30">Mobile: joystick + buttons</p>
          </div>
        </Overlay>
      )}

      {/* ---------- EVOLVE ---------- */}
      {state === 'evolve' && hud && (
        <Overlay>
          <div className="w-[min(96vw,860px)] px-2 text-center">
            <h2 className="animate-[pop_.35s_ease-out] text-3xl font-black tracking-tight text-lime-300 drop-shadow sm:text-4xl">
              🧬 MUTATION UNLOCKED
            </h2>
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.3em] text-white/50">Level {hud.level} · choose your path</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              {hud.choices.map((c, i) => (
                <button
                  key={c.def.key}
                  onClick={() => g?.choose(i)}
                  className="group relative overflow-hidden rounded-2xl border-2 bg-[#0d150f]/90 p-4 text-left transition hover:-translate-y-1 active:scale-[0.98]"
                  style={{ borderColor: c.def.color + '66', boxShadow: `0 0 28px ${c.def.color}22` }}
                >
                  <div className="absolute -right-6 -top-6 text-7xl opacity-10">{c.def.icon}</div>
                  <div className="text-3xl">{c.def.icon}</div>
                  <div className="mt-1 text-[10px] font-black uppercase tracking-widest" style={{ color: c.def.color }}>
                    {c.def.branch} · TIER {c.tier}
                  </div>
                  <div className="text-lg font-black text-white">{c.def.name}</div>
                  <div className="mt-1 text-xs leading-relaxed text-white/70">{c.def.desc(c.tier)}</div>
                  <div className="mt-3 text-[10px] font-bold text-white/30">PRESS {i + 1}</div>
                </button>
              ))}
            </div>
          </div>
        </Overlay>
      )}

      {/* ---------- PAUSE ---------- */}
      {state === 'paused' && hud && (
        <Overlay>
          <div className="w-[min(92vw,420px)] rounded-3xl border border-white/15 bg-[#0d150f]/90 p-6 text-center backdrop-blur-md">
            <h2 className="text-3xl font-black tracking-tight">PAUSED</h2>
            <div className="mt-4 grid grid-cols-2 gap-2 text-left text-sm">
              <Stat label="Score" value={hud.score.toLocaleString()} />
              <Stat label="Survived" value={fmtTime(hud.time)} />
              <Stat label="Evolution" value={'LV ' + hud.level} />
              <Stat label="Predators slain" value={String(hud.kills)} />
            </div>
            {hud.traits.length > 0 && (
              <div className="mt-3 flex flex-wrap justify-center gap-1.5">
                {hud.traits.map((t) => (
                  <span key={t.name} className="rounded-md bg-white/5 px-2 py-1 text-[11px] font-bold" style={{ color: t.color }}>
                    {t.icon} {t.name} {t.tier}
                  </span>
                ))}
              </div>
            )}
            <div className="mt-5 flex gap-2">
              <button onClick={() => { if (g) { g.state = 'playing'; g.pushHud(); } }} className="flex-1 rounded-xl bg-gradient-to-b from-lime-400 to-emerald-600 py-3 font-black text-[#0d150f] shadow-[0_4px_0_#14532d] active:translate-y-0.5">
                RESUME
              </button>
              <button onClick={startGame} className="rounded-xl border border-white/20 px-4 py-3 text-sm font-bold text-white/70 active:scale-95">
                RESTART
              </button>
            </div>
          </div>
        </Overlay>
      )}

      {/* ---------- GAME OVER ---------- */}
      {state === 'dead' && hud && (
        <Overlay>
          <div className="w-[min(94vw,520px)] rounded-3xl border border-rose-500/30 bg-[#150d0d]/90 p-6 text-center shadow-2xl backdrop-blur-md">
            <div className="text-5xl">💀</div>
            <h2 className="text-3xl font-black tracking-tight text-rose-300">EXTINCTION</h2>
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-white/40">
              Your lineage ended in the {hud.eraName}
            </p>
            <div className="mt-4 text-5xl font-black tabular-nums text-amber-200 drop-shadow">{hud.score.toLocaleString()}</div>
            <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
              <Stat label="Survived" value={fmtTime(hud.time)} />
              <Stat label="Level" value={String(hud.level)} />
              <Stat label="Kills" value={String(hud.kills)} />
            </div>
            <div className="mt-4 rounded-xl border border-white/10 bg-black/40 p-3 text-left">
              <div className="mb-1 text-[10px] font-black uppercase tracking-widest text-white/40">🏆 Fossil Record</div>
              {scores.map((s, i) => (
                <div
                  key={i}
                  className={`flex items-center justify-between rounded px-1.5 py-0.5 text-xs ${s.score === hud.score && i === scores.findIndex((x) => x.score === hud.score) ? 'bg-amber-400/15 text-amber-200' : 'text-white/60'}`}
                >
                  <span className="font-bold">#{i + 1}</span>
                  <span className="font-mono font-bold">{s.score.toLocaleString()}</span>
                  <span className="opacity-60">LV{s.level} · {fmtTime(s.time)} · {s.kills}☠</span>
                </div>
              ))}
            </div>
            <button
              onClick={startGame}
              className="mt-5 w-full rounded-2xl bg-gradient-to-b from-lime-400 to-emerald-600 py-4 text-xl font-black text-[#0d150f] shadow-[0_6px_0_#14532d] active:translate-y-1 active:shadow-[0_2px_0_#14532d]"
            >
              ↻ EVOLVE AGAIN
            </button>
            <p className="mt-2 text-[10px] text-white/30">or press ENTER</p>
          </div>
        </Overlay>
      )}
    </div>
  );
}

const Overlay = ({ children }: { children: React.ReactNode }) => (
  <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/55 p-3 backdrop-blur-[2px] animate-[fade_.2s_ease-out]">
    {children}
  </div>
);

const Stat = ({ label, value }: { label: string; value: string }) => (
  <div className="rounded-lg bg-white/5 px-2 py-1.5">
    <div className="text-[9px] font-black uppercase tracking-widest text-white/40">{label}</div>
    <div className="font-black text-white">{value}</div>
  </div>
);

const Key = ({ k, v }: { k: string; v: string }) => (
  <div className="rounded-lg border border-white/10 bg-white/5 px-2 py-1.5">
    <div className="font-mono text-[10px] font-bold text-lime-300">{k}</div>
    <div>{v}</div>
  </div>
);
